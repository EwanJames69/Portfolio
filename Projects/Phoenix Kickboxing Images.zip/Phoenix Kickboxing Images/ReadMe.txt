These images are provided to allow you to get a better look at the design of the mobile application.
The reason for not allowing the user to download the actual application is because this mobile app is currently
being tested in order to be published on to the Google Play Store. This obviously means the team wants to keep
the rights to the application private. Thank you for understanding.

If you have any queries or questions about the mobile application, please don't hesitate to contact me:
Phone number - +27 064 909 1040
Email: ewanjames52@gmail.com
LinkedIn: https://www.linkedin.com/in/ewan-james-33364322b/
GitHub: EwanJames69